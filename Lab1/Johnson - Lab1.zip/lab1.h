#include <stdio.h>
#include <stdlib.h>

int getMin(int size, int *array, int *result);
