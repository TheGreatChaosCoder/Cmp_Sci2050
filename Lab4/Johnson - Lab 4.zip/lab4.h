#include <stdio.h>
#include <stdlib.h>

short * createArray(int size);
int getSize(short *array);

int countGreater(short *array, int query);

void freeArray(short *array);
